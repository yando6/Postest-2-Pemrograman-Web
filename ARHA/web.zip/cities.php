<?php
  $cities = array("Samarinda", "Tenggarong", "Balikpapan","Berau","Kutai Barat","Kutai Kartanegara","Kutai Timur","Mahakam Ulu","Paser","Penajam Paser Utara");
?>
